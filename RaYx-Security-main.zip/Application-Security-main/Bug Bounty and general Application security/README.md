
## Bug Bounty Platform

  - [HackerOne](https://hackerone.com/)
  - [BugCrowd](https://www.bugcrowd.com/)

## Reports and Article

- [HackerOne Hactivity](https://hackerone.com/hacktivity)
- [InfoSec Write-Ups](https://infosecwriteups.com/)
- [Pentester Land](https://pentester.land/)
